#ifndef COCOA_HELPERS_H
#define COCOA_HELPERS_H

const char* getResourcesPath(void);
const char* getDocumentsPath(void);

#endif
